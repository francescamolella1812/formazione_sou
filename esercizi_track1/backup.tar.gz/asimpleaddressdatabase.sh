#!/bin/bash
# fetch_address.sh

declare -A address
# -A option declares associative array.

address[Charles]="414 W. 10th Ave., Baltimore, MD 21236"
address[John]="202 E. 3rd St., New York, NY 10009"
address[Wilma]="1854 Vermont Ave, Los Angeles, CA 90023"

echo "Charles's address is ${address[Charles]}."
# Charles's address is 414 W. 10th Ave., baltimore, MD 21236.

echo "Wilma's address is ${address[Wilma]}."
#Wilma's address is 1854 Vermont Ave, Los Angeles, CA 90023.

echo "John's address is ${address[John]}."
#John's address is 202 E. 3rd St., New  York, NY 10009.

echo
echo "${!address[*]}" #the array indices ...
#Charles John Wilma


